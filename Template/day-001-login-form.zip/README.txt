A Pen created at CodePen.io. You can find this one at http://codepen.io/khadkamhn/pen/ZGvPLo.

 Design is based from dribble.com http://dribbble.com/shots/2125879-Day-001-Login-Form